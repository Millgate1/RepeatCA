# --- Sample dataset

# --- !Ups

insert into category (id,name) values ( 1,'First-Person Shooter' );
insert into category (id,name) values ( 2,'Role Playing Game' );
insert into category (id,name) values ( 3,'Real Time Strategy' );
insert into category (id,name) values ( 4,'Puzzle' );
insert into category (id,name) values ( 5,'Horror' );
insert into category (id,name) values ( 6,'Racing' );
insert into category (id,name) values ( 7,'Third Person Shooter' ); 
insert into category (id,name) values ( 8,'Platformer' ); 

insert into product (id,name,description,stock,price) values ( 1,'Borderlands 2','Loooot',100,55.00 );
insert into product (id,name,description,stock,price) values ( 2,'Battlefield 4','Boom boom',45,799.00 );
insert into product (id,name,description,stock,price) values ( 3,'Portal 2','Brain hurts',5,99.00 );
insert into product (id,name,description,stock,price) values ( 4,'Batman: Arkham City','Swear to me',45,799.00 );
insert into product (id,name,description,stock,price) values ( 5,'Company of Heroes 2','RTS',5,99.00 );
insert into product (id,name,description,stock,price) values ( 6,'Call of Duty: World War II','Microtransactions',12,2799.00 );
insert into product (id,name,description,stock,price) values ( 7,'The Witcher 3','Good stuff',50,699.00 );
insert into product (id,name,description,stock,price) values ( 8,'Mortal Kombat XL','FIGHT!',45, 14.99 );
insert into product (id,name,description,stock,price) values ( 9,'Shovel Knight','Retro Platformer',5,19.99 );
insert into product (id,name,description,stock,price) values ( 10,'Dirt 4','Vroom Vroom',10,19.99);
insert into product (id,name,description,stock,price) values ( 11,'Grand Theft Auto V','GTA',5,29.99 );
insert into product (id,name,description,stock,price) values ( 12,'Dead by Daylight','Horror with friends',50,19.99 );

insert into category_product (category_id,product_id) values (1,1);
insert into category_product (category_id,product_id) values (1,2);
insert into category_product (category_id,product_id) values (4,3);
insert into category_product (category_id,product_id) values (7,4);
insert into category_product (category_id,product_id) values (3,5);
insert into category_product (category_id,product_id) values (8,6);
insert into category_product (category_id,product_id) values (2,7);
insert into category_product (category_id,product_id) values (7,8);  
 insert into category_product (category_id,product_id) values (3,9);
insert into category_product (category_id,product_id) values (5,10);
insert into category_product (category_id,product_id) values (4,11);
insert into category_product (category_id,product_id) values (2,12);
insert into category_product (category_id,product_id) values (5,7);
insert into category_product (category_id,product_id) values (3,8);
insert into category_product (category_id,product_id) values (3,3);  

insert into user (email,name,password,role) values ( 'admin@products.com', 'Alice Admin', 'password', 'admin' );
insert into user (email,name,password,role) values ( 'manager@products.com', 'Bob Manager', 'password', 'manager' );
insert into user (email,name,password,role) values ( 'customer@products.com', 'Charlie Customer', 'password', 'customer' );
